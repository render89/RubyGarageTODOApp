var app = angular.module('myApp', ['ngRoute'])
  .config(function($routeProvider, $locationProvider){
    $routeProvider
      .when('/', {
        templateUrl: 'login.html',
        controller: 'loginController'
        })
      .when('/registration', {
        templateUrl: 'registration.html',
        controller: 'registrationController'
        })
      .when('/projects', {
        templateUrl: 'project-list.html',
        controller: 'projectsListController'
        })
  })
  .controller('projectsListController', function($scope, $http){
     $scope.projectList = [];
     
     $http.get('/api/projects')
      .then(function(project_list){
		  //console.log(Array.isArray(project_list));
		  if(Array.isArray(project_list.data)){ // проверка на массив
			  // проверка на обьект - typeof project_list === 'object'; -string -number
        		$scope.projectList = project_list.data;  // присваиваем проекты, которые пришли с сервера
		  }
      })
      .catch(function(error){
        console.error(error);
      });
	  
	  
	  $scope.addProject = function(){
		  $http.post('/api/projects') // урл всегда один, в путе и делите + ид
      	.then(function(project){
			  	console.log(project.data);
        		$scope.projectList.push(project.data); // добавляем новый проект
      	})
      	.catch(function(error){
        		console.error(error);
      	})
	  };
	  $scope.deleteProject = function(project){
		  $http.delete('/api/projects/' + project.id) // передали проджект из вьюхи, не обязательно проджект любое название, 
			.then(function(){
				$scope.projectList = $scope.projectList.filter(function(proj){
					return proj.id !== project.id; // proj - шопопаломб, вторая строка - в массив все элементы в которых айди не равен тому который мы удалили
				});
			})
			.catch(function(error){
				console.error(error);
			});
		};
	  
  })
  .controller('mainController', function($scope, $location, $routeParams) {
    $scope.$location = $location;
    $scope.$routeParams = $routeParams;
  })
  .controller('loginController', function($scope){
  })
  .controller('registrationController', function($scope){ // $scope - need, (angular)
  })
  .directive('projectsDirective', function($http){ // $http - need, (angular)
     return {
        restrict: 'E',
        link: function(scope){
                  scope.nameEditable = false;
                  scope.changeProjectName = function(){
                    scope.nameEditable = true;
                  };
                  scope.saveProjectName = function(event, project){
							var data = {name: project.name}
                    	if(event.keyCode == 13){
								$http.put('/api/projects/' +project.id, data)
									.then(function(updated_project){
								 		if(project.name == updated_project.data.name){
											console.log('Изменено');// project - во вьюхе, updated_project - нами придуманый из базы данных
											scope.nameEditable = false;
										}
							 		})
							  		.catch(function(error){
        								console.error(error);
      							});
                    	}
                  };
                  scope.changeTaskName = function(task){
                    task.nameEditable = true;
                  };
                  scope.saveTaskName = function(event, task){
                    if(event.keyCode == 13){
                      task.nameEditable = false;
                    }
                  };
        },
        scope: {
            project: "=projectOuter",
			  	deleteProject:  "=projectDelete"
        },
        templateUrl: 'project.html'
    };
  });
  // тут 2 директивы
  
  
     